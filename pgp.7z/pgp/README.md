<p align="center">
  <a href="https://xtaolabs.com"><img src="pagermaid/assets/logo.jpg" width="200" height="200" alt="pagermaid"></a>
</p>

<div align="center">

# PagerMaid-Pyro

_✨ 您必备的 Telegram 聊天工具箱 ✨_

</div>

<p align="center">
  <a href="https://xtaolabs.com">文档</a>
  ·
  <a href="https://xtaolabs.com">安装</a>
</p>

# 简介

PagerMaid-Pyro 是一个开源的 Telegram 人形自走 Bot 方案，功能强大而丰富，可以帮助你打造专属的便利功能。
