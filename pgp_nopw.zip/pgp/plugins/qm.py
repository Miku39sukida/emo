import asyncio
import contextlib
from pagermaid import Config, log, logs
from pagermaid.listener import listener
from pyrogram.types import Message, InputMediaDocument
from pagermaid.enums import Client, Message, AsyncClient
from pyrogram.enums import ChatType
from pagermaid.utils import lang, pip_install
from pagermaid.services import client as requests
import urllib.parse
import random
import json

@listener(command="qm",
          description="多个快捷消息，输入 `,qm h` 获取帮助",
          parameters="[指令参数]")
async def test(client: Client, message: Message, request: AsyncClient):
    if message.parameter[0] == "alsc":
      await message.edit('您好，请使用下面指令搜索\n/s 关键词\n\n指令和关键词之间都有空格，例如：\n/s 最终幻想')
    if message.parameter[0] == "cao":
      await message.edit('[草](tg://setlanguage?lang=caolang)（蓝色文字可以点击）')
    if message.parameter[0] == "cn":
      await message.edit('*** 点击下面链接快捷设置中文**\n\n[中文（TG_CN）](https://t.me/setlanguage/chinese-tg-cn)')
    if message.parameter[0] == "cncc":
      await message.edit('*** 点击下面链接快捷设置中文\n\n[中文（聪聪）](https://t.me/setlanguage/zhcncc)')
    if message.parameter[0] == "chrome":
      await message.edit('点击下载 [Google Chrome](https://www.google.cn/chrome)')
    if message.parameter[0] == "dxzp":
      await message.edit('谨防盗号！谨防盗号！谨防盗号！\n\n仔细看: https://t.me/tgcnz/963\n\n仔细看: https://t.me/tgcnz/965')
    if message.parameter[0] == "dhsj":
      await message.edit('谨防盗号！谨防盗号！谨防盗号！\n\n仔细看: https://t.me/TG_BangZhu/69')
    if message.parameter[0] == "ggsjt":
      await message.edit('点击下载[Google三件套](https://t.me/HatsuneMiku_39_suki/69)，只要你手机支持就行。')
    if message.parameter[0] == "iospb":
      await message.edit('**Telegram iOS 开车群屏蔽**\n原因是 telegram为了能在App Store 上架做出的妥协\n[如何解除](https://t.me/TG_BangZhu/23)')
    if message.parameter[0] == "iospb3":
      await message.edit('网页版新版：手机或电脑浏览器访问[官方网页版](https://web.telegram.org/)，输入手机号码登录(验证码是优先发送到之前已登录的 Telegram 设备/客户端/App上)，主界面→左上角三短线→Settings→点击“Privacy and Security”→滑动到底部，打开“Disable filtering”。\n  注意: 必须用浏览器打开，验证码是优先发送到之前已登录的 Telegram 设备/客户端/App上。如果你在Telegram直接打开链接，就无法看到 Telegram 上的验证码了.')
    if message.parameter[0] == "iospbx":
      await message.edit('**iOS 解决方法：**https://t.me/tgcnz/867')
    if message.parameter[0] == "owokf":
      await message.edit('本店客服工作时间为 9:00-18:00，如有需要请联系 @OwO_233。请勿骚扰其他群管理或在非工作时间打电话。')
    if message.parameter[0] == "owo":
      await message.edit('您好，请根据自己的需要选择网站购买。\n**GV、Gmail** 等**成品账户**购买： shop.owo233.xyz\n**TG内置代理**购买： owo233.tg88.us\n国内各平台**会员代购**及**合租**： owo233.huiyuan2.xyz')
    if message.parameter[0] == "owoair":
      await message.edit('https://t.me/OwO_Shop/483')
    if message.parameter[0] == "pmbot":
      await message.edit('发两个私聊机器人吧，这里二选一。\n@afoolchatrobot\n@LivegramBot\n\n**步骤：**\n先用 @BotFather 创建机器人。\n私聊发送指令 /newbot ，第一步就是给机器人起个**昵称**。\n第二步就是设置机器人的**用户名**，以**bot**为结尾。\n创建完之后，**点击复制token**，发送给其中一个**私聊机器人**就行，这样就**创建成功**啦！')
    if message.parameter[0] == "shop":
      await message.edit('您好，网站下单即可：\nshop.owo233.xyz')
    if message.parameter[0] == "soshu":
      await message.edit('搜书、签到等，请私聊机器人 @sosdbot ，在群里没用！请理解')
    if message.parameter[0] == "sx":
      await message.edit('解除 +86 双向联系人私聊限制方法:\n* https://t.me/tgcnz/480')
    if message.parameter[0] == "tdata":
      await message.edit('教程：https://t.me/OwO_Shop/2145')
    if message.parameter[0] == "tg":
      await message.edit('[点击下载](https://telegram.org/)')
    if message.parameter[0] == "tg88":
      await message.edit('TG代理&接码在这里：\nowo233.tg88.us')
    if message.parameter[0] == "tgjf":
      await message.edit('登录Telegram的时候，提示被封禁，可以点击弹窗下面的帮助（Help）通过邮箱反馈。\n如果不行就试试官网 telegram.org/support\n\n必须要根据自己的情况详细说明，才有解封的可能，如果这样还是不行，那就没办法了。下面是翻译\n\nPlease describe your problem\n请描述您的问题\n\nYour email\n您的邮箱\n\nYour phone number\n您的手机号（指的是账号绑定的）\n\nSubmit\n提交')
    if message.parameter[0] == "tokent":
      await message.edit('登录Twitter教程[请看这里](https://t.me/OwO_Shop/1293)，需要用token。')
    if message.parameter[0] == "wm":
      await message.edit('这里是無名机器人的官方群组，请注意不要找错地方。')
    if message.parameter[0] == "wvcn":
      await message.edit('抱歉的是，网页版是没办法汉化的，必须要使用APP才可以！[点击下载](https://telegram.org/)')
    if message.parameter[0] == "yfzf":
      await message.edit('如果支付完成 出现问题的话，可以通过机器人 @yifenjc_bot 私聊群主发送订单截图，说明情况。\n群主有时候不在线，所以发了订单之后请耐心等待。')
    if message.parameter[0] == "yzm":
      await message.edit('如果有设备登录了帐号，一般接收验证码都是通过Telegram私信发送的，所以请注意查看[官方私信](https://t.me/+42777)。\n如果所有设备没有登录、或者第一次注册的话，那就是通过短信发送，要是收不到，可以通过电话语音接收。\n另外注意的是：手机短信验证码一般只能用官方应用登录或注册才能收到，非官方应用是无法收到短信验证码的，所以请[点击下载](https://telegram.org/)，实在不行就试试[Telegram X](https://play.google.com/store/apps/details?id=org.thunderdog.challegram)！')
    if message.parameter[0] == "yzmwt":
      await message.edit('有设备登录 但是又坏掉，如果手机号还在的话，可以选择短信接收。当然还有一种登入方法，电脑的Telegram便携版是可以保存登录数据的，就在tdata文件夹，进去选择文件打包压缩包（但是运行的时候没法正常打包），保存到U盘或者个人云盘，不过那个大文件夹的就是缓存。\n另外如果手机号用不了，又没有保存tdata登录数据文件夹，或者突然被强制下线的话，可以尝试向官方申请回执，必须明确说明情况，应该会给出答复。\n手机被偷，没有其他可用设备，可以向官方申请退出登录，只要填写的信息够全，应该会给回复。要是不行的话就说明那个号废了，只能重新再注册或买一个。')
    if message.parameter[0] == "zxl":
      await message.edit('https://t.me/OwO_Shop/2150')
    if message.parameter[0] == "zysx":
      await message.edit('资源没了？解决方法[看这里](https://t.me/shareAliyun/27776)')
    if message.parameter[0] == "h":
      await message.edit('帮助：\n\n`alsc` 提供搜索帮助\n`cao` 快捷发送草语包链接\n`cn` 提供中文设置链接\n`cncc` 聪聪制作\n`chrome` 不用说明，已经很明显了\n`dhsj` @TG_CN 发布的盗号事件防范帮助\n`dxzp` 提示用户那是盗号诈骗行为\n`ggsjt` Google三件套\n`iospb` iOS屏蔽的解决方法，指令后面加上数字即可快捷发送指定方案。\n`iospbx` 一样，就是内容不同\n`owokf` 清风阁客服工作时间\n`owo` 快捷发送商店的地址，感谢叶清风OwO\n😘\n`owoair` 推荐清风阁商店里发的机场链接\n`pmbot` 私聊机器人，如果号有问题，可以用到。\n`shop` 清风阁商店\n`soshu` 提醒用户私聊机器人搜书\n`sx` 快捷发送解除双向的方法\n`tdata` TG成品号登录视频教程\n`tg` 官方软件\n`tg88` 若楠小店\n`tgjf` 官网反馈入口。\n`tokent` Twitter成品号登录教程\n`wvcn` 提醒用户使用APP设置中文\n`yfzf` 一分机场支付的问题\n`yzm` 验证码收不到的问题\n`yzmwt` 手机出了问题？\n`zxl` GV和老GV滞销啦\n`zysx` 什么？投稿的阿里云盘资源失效了？\n`h` 帮助菜单')